# SlidingTile-Project-

To use this project you must use in the commmand prompt type (make all). After you make all you must then type in the command prompt (./a.out) which will then run the project for you to use 
An aside note is that the main.cpp is labled as cool.cpp.
The project report will be in this Github repository as well as in a seperate file to ensure that we dont miss it.
Thank you !
